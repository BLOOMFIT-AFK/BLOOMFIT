import { useMemo, useState } from 'react';
import {
  Activity,
  Apple,
  Check,
  ChevronRight,
  Clock,
  Droplets,
  Dumbbell,
  Heart,
  Leaf,
  Menu,
  RotateCcw,
  Sparkles,
  Target,
  Utensils,
  Waves,
  X,
} from 'lucide-react';

type Profile = {
  age: string;
  height: string;
  weight: string;
  activity: string;
  preference: string;
  goal: string;
};
const starter: Profile = {
  age: '',
  height: '',
  weight: '',
  activity: 'light',
  preference: 'vegetarian',
  goal: 'fat-loss',
};

const plans = {
  vegetarian: [
    {
      time: 'BREAKFAST',
      title: 'A filling start',
      meal: 'Poha or oats with milk/curd and a fruit',
      icon: '☀️',
    },
    {
      time: 'LUNCH',
      title: 'Build a balanced plate',
      meal: 'Roti or rice, dal/rajma/chole, sabzi and curd',
      icon: '🥗',
    },
    {
      time: 'SNACK',
      title: 'Afternoon recharge',
      meal: 'Fruit, roasted chana, nuts or yogurt',
      icon: '🍎',
    },
    {
      time: 'DINNER',
      title: 'Comforting dinner',
      meal: 'Paneer/tofu or dal, vegetables and roti or rice',
      icon: '🍲',
    },
  ],
  egg: [
    {
      time: 'BREAKFAST',
      title: 'A filling start',
      meal: 'Eggs with toast/roti, plus fruit or milk',
      icon: '☀️',
    },
    {
      time: 'LUNCH',
      title: 'Build a balanced plate',
      meal: 'Roti or rice, dal, sabzi, curd and egg/paneer',
      icon: '🥗',
    },
    {
      time: 'SNACK',
      title: 'Afternoon recharge',
      meal: 'Fruit, roasted chana, nuts or yogurt',
      icon: '🍎',
    },
    {
      time: 'DINNER',
      title: 'Comforting dinner',
      meal: 'Egg bhurji or paneer, vegetables and roti/rice',
      icon: '🍲',
    },
  ],
  nonveg: [
    {
      time: 'BREAKFAST',
      title: 'A filling start',
      meal: 'Eggs or paneer with toast/roti, plus fruit',
      icon: '☀️',
    },
    {
      time: 'LUNCH',
      title: 'Build a balanced plate',
      meal: 'Roti or rice, dal, sabzi, curd and chicken/fish',
      icon: '🥗',
    },
    {
      time: 'SNACK',
      title: 'Afternoon recharge',
      meal: 'Fruit, roasted chana, nuts or yogurt',
      icon: '🍎',
    },
    {
      time: 'DINNER',
      title: 'Comforting dinner',
      meal: 'Chicken/fish or dal, vegetables and roti/rice',
      icon: '🍲',
    },
  ],
};
const fatLossWorkouts = [
  {
    name: 'Brisk walk quest',
    detail: 'Walk at a pace that feels lively but still lets you talk',
    time: '15–25 min',
    icon: '🚶',
    level: 'Easy',
  },
  {
    name: 'Full-body basics',
    detail: 'Chair squats, wall push-ups and bird-dogs; rest between sets',
    time: '8–12 min',
    icon: '💪',
    level: 'Beginner',
  },
  {
    name: 'Dance cardio',
    detail: 'Dance to favourite songs and pause whenever you need',
    time: '2–4 songs',
    icon: '🎵',
    level: 'Fun',
  },
  {
    name: 'Mobility reset',
    detail: 'Gentle stretches, arm circles and cat-cow',
    time: '5–8 min',
    icon: '🧘',
    level: 'Recovery',
  },
];
const exerciseLibrary = [
  { name: 'Bicep curls', group: 'Arms', equipment: 'Dumbbells or resistance band' },
  { name: 'Hammer curls', group: 'Arms', equipment: 'Dumbbells' },
  { name: 'Reverse curls', group: 'Arms', equipment: 'Dumbbells or barbell' },
  { name: 'Reverse bicycle curls', group: 'Arms', equipment: 'Light dumbbells; use controlled form' },
  { name: 'Concentration curls', group: 'Arms', equipment: 'Dumbbell' },
  { name: 'Preacher curls', group: 'Arms', equipment: 'Bench and dumbbell or machine' },
  { name: 'Tricep extensions', group: 'Arms', equipment: 'Dumbbell or band' },
  { name: 'Tricep kickbacks', group: 'Arms', equipment: 'Light dumbbells' },
  { name: 'Diamond push-ups', group: 'Arms & chest', equipment: 'Bodyweight; use an easier incline version if needed' },
  { name: 'Wrist curls', group: 'Forearms', equipment: 'Light dumbbells' },
  { name: 'Reverse wrist curls', group: 'Forearms', equipment: 'Light dumbbells' },
  { name: 'Push-ups', group: 'Chest', equipment: 'Bodyweight or wall/incline variation' },
  { name: 'Incline push-ups', group: 'Chest', equipment: 'Stable bench or wall' },
  { name: 'Dumbbell bench press', group: 'Chest', equipment: 'Dumbbells and bench' },
  { name: 'Chest fly', group: 'Chest', equipment: 'Light dumbbells or machine' },
  { name: 'Chest press', group: 'Chest', equipment: 'Machine or dumbbells' },
  { name: 'Lat pulldown', group: 'Back', equipment: 'Gym machine' },
  { name: 'Seated cable row', group: 'Back', equipment: 'Cable machine' },
  { name: 'One-arm dumbbell row', group: 'Back', equipment: 'Dumbbell and stable support' },
  { name: 'Bent-over row', group: 'Back', equipment: 'Light dumbbells or barbell' },
  { name: 'Superman hold', group: 'Back', equipment: 'Bodyweight' },
  { name: 'Shoulder press', group: 'Shoulders', equipment: 'Dumbbells or machine' },
  { name: 'Lateral raises', group: 'Shoulders', equipment: 'Light dumbbells' },
  { name: 'Front raises', group: 'Shoulders', equipment: 'Light dumbbells' },
  { name: 'Rear delt fly', group: 'Shoulders', equipment: 'Light dumbbells or machine' },
  { name: 'Shrugs', group: 'Shoulders', equipment: 'Dumbbells' },
  { name: 'Bodyweight squats', group: 'Legs', equipment: 'Bodyweight' },
  { name: 'Chair squats', group: 'Legs', equipment: 'Stable chair' },
  { name: 'Goblet squats', group: 'Legs', equipment: 'One light dumbbell' },
  { name: 'Lunges', group: 'Legs', equipment: 'Bodyweight or light dumbbells' },
  { name: 'Reverse lunges', group: 'Legs', equipment: 'Bodyweight' },
  { name: 'Step-ups', group: 'Legs', equipment: 'Low, stable step' },
  { name: 'Glute bridges', group: 'Glutes', equipment: 'Bodyweight' },
  { name: 'Hip thrusts', group: 'Glutes', equipment: 'Bodyweight or light load' },
  { name: 'Romanian deadlift', group: 'Legs & back', equipment: 'Light dumbbells; learn technique first' },
  { name: 'Calf raises', group: 'Legs', equipment: 'Bodyweight or light support' },
  { name: 'Leg extension', group: 'Legs', equipment: 'Gym machine' },
  { name: 'Hamstring curl', group: 'Legs', equipment: 'Gym machine' },
  { name: 'Wall sit', group: 'Legs', equipment: 'Wall and bodyweight' },
  { name: 'Plank', group: 'Core', equipment: 'Bodyweight; knees-down version is fine' },
  { name: 'Side plank', group: 'Core', equipment: 'Bodyweight; knees-down version is fine' },
  { name: 'Dead bug', group: 'Core', equipment: 'Bodyweight' },
  { name: 'Bird-dog', group: 'Core', equipment: 'Bodyweight' },
  { name: 'Bicycle crunches', group: 'Core', equipment: 'Bodyweight; slow and controlled' },
  { name: 'Reverse crunches', group: 'Core', equipment: 'Bodyweight' },
  { name: 'Reverse bicycle crunches', group: 'Core', equipment: 'Bodyweight; slow and controlled' },
  { name: 'Mountain climbers', group: 'Core & cardio', equipment: 'Bodyweight; slow variation available' },
  { name: 'Russian twists', group: 'Core', equipment: 'Bodyweight; no need to add weight' },
  { name: 'Leg raises', group: 'Core', equipment: 'Bodyweight; bend knees if needed' },
  { name: 'Heel taps', group: 'Core', equipment: 'Bodyweight' },
  { name: 'Jumping jacks', group: 'Cardio', equipment: 'Bodyweight; step side to side for low impact' },
  { name: 'High knees', group: 'Cardio', equipment: 'Bodyweight; march in place for low impact' },
  { name: 'March in place', group: 'Cardio', equipment: 'No equipment' },
  { name: 'Brisk walking', group: 'Cardio', equipment: 'Comfortable shoes' },
  { name: 'Jogging', group: 'Cardio', equipment: 'Comfortable shoes; choose a manageable pace' },
  { name: 'Cycling', group: 'Cardio', equipment: 'Bicycle or stationary bike' },
  { name: 'Skipping rope', group: 'Cardio', equipment: 'Jump rope; low-impact alternative is fine' },
  { name: 'Dancing', group: 'Cardio', equipment: 'Music optional' },
  { name: 'Swimming', group: 'Cardio', equipment: 'Safe supervised swimming area' },
  { name: 'Burpees', group: 'Full body', equipment: 'Bodyweight; step-back variation is easier' },
  { name: 'Bear crawl', group: 'Full body', equipment: 'Bodyweight' },
  { name: 'Inchworms', group: 'Full body', equipment: 'Bodyweight' },
  { name: 'Wall push-ups', group: 'Full body', equipment: 'Wall' },
  { name: 'Cat-cow stretch', group: 'Mobility', equipment: 'Bodyweight' },
  { name: 'Child’s pose', group: 'Mobility', equipment: 'Bodyweight' },
  { name: 'Hamstring stretch', group: 'Mobility', equipment: 'Bodyweight' },
  { name: 'Shoulder circles', group: 'Mobility', equipment: 'No equipment' },
];
const weightGainWorkouts = [
  {
    name: 'Strength starter',
    detail: 'Chair squats, wall push-ups and glute bridges with controlled form',
    time: '10–15 min',
    icon: '💪',
    level: 'Beginner',
  },
  {
    name: 'Core & balance',
    detail: 'Bird-dogs, standing knee raises and gentle balance practice',
    time: '8–12 min',
    icon: '🎯',
    level: 'Beginner',
  },
  {
    name: 'Active recovery walk',
    detail: 'An easy walk to loosen up, not a race',
    time: '10–20 min',
    icon: '🚶',
    level: 'Easy',
  },
  {
    name: 'Stretch & reset',
    detail: 'Gentle stretches and relaxed breathing',
    time: '5–8 min',
    icon: '🧘',
    level: 'Recovery',
  },
];

function App() {
  const [profile, setProfile] = useState<Profile>(() => {
    try {
      return {
        ...starter,
        ...JSON.parse(localStorage.getItem('bloomfit-profile') || '{}'),
      };
    } catch {
      return starter;
    }
  });
  const [setup, setSetup] = useState(!profile.age);
  const [tab, setTab] = useState('Today');
  const [done, setDone] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('bloomfit-done') || '[]');
    } catch {
      return [];
    }
  });
  const [water, setWater] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [exerciseSearch, setExerciseSearch] = useState('');
  const [exerciseLog, setExerciseLog] = useState<Record<string, string[]>>(() => {
    try {
      return JSON.parse(localStorage.getItem('bloomfit-exercise-log') || '{}');
    } catch {
      return {};
    }
  });
  const age = Number(profile.age);
  const isTeen = age > 0 && age < 18;
  const mealPlan =
    plans[profile.preference as keyof typeof plans] || plans.vegetarian;
  const workouts = profile.goal === 'weight-gain' ? weightGainWorkouts : fatLossWorkouts;
  const greeting = age ? 'Your day, your pace.' : 'Small steps count.';
  const progress = Math.round((done.filter(x => ['move','meals','water','rest'].includes(x)).length / 4) * 100);
  const xp = done.length * 25;
  const level = Math.floor(xp / 100) + 1;
  const rank = level < 2 ? 'FROST ROOKIE' : level < 4 ? 'SNOW STRIDER' : level < 7 ? 'ICE WARRIOR' : 'WINTER LEGEND';
  const today = useMemo(
    () =>
      new Date().toLocaleDateString(undefined, {
        weekday: 'long',
        month: 'short',
        day: 'numeric',
      }),
    []
  );
  const dateKey = new Date().getFullYear() + '-' + String(new Date().getMonth() + 1).padStart(2, '0') + '-' + String(new Date().getDate()).padStart(2, '0');
  const todaysExercises = exerciseLog[dateKey] || [];
  const filteredExercises = exerciseLibrary.filter(exercise =>
    (exercise.name + ' ' + exercise.group + ' ' + exercise.equipment).toLowerCase().includes(exerciseSearch.toLowerCase().trim())
  );
  const weeklyScores = Array.from({ length: 7 }, (_, index) => {
    const day = new Date();
    day.setDate(day.getDate() - (6 - index));
    const key = day.getFullYear() + '-' + String(day.getMonth() + 1).padStart(2, '0') + '-' + String(day.getDate()).padStart(2, '0');
    return { key, label: day.toLocaleDateString(undefined, { weekday: 'short' }), count: (exerciseLog[key] || []).length, score: (exerciseLog[key] || []).length * 10 };
  });

  function saveProfile(next: Profile) {
    setProfile(next);
    localStorage.setItem('bloomfit-profile', JSON.stringify(next));
    setSetup(false);
  }
  function toggleDone(name: string) {
    const next = done.includes(name)
      ? done.filter(x => x !== name)
      : [...done, name];
    setDone(next);
    localStorage.setItem('bloomfit-done', JSON.stringify(next));
  }
  function resetDay() {
    setDone([]);
    localStorage.setItem('bloomfit-done', '[]');
    setWater(0);
  }
  function toggleExercise(name: string) {
    const current = exerciseLog[dateKey] || [];
    const updatedToday = current.includes(name) ? current.filter(item => item !== name) : [...current, name];
    const next = { ...exerciseLog, [dateKey]: updatedToday };
    setExerciseLog(next);
    localStorage.setItem('bloomfit-exercise-log', JSON.stringify(next));
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">
            <Leaf size={22} />
          </div>
          <span className="winter-brand">BLOOMFIT <small>WINTER ARC</small></span>
        </div>
        <div className="side-label">WINTER ARC</div>
        {['Today', 'Meal ideas', 'Movement', 'My profile'].map((item, i) => (
          <button
            key={item}
            className={'nav-item ' + (tab === item ? 'active' : '')}
            onClick={() => {
              setTab(item);
              setMenuOpen(false);
            }}
          >
            {i === 0 ? (
              <Sparkles size={18} />
            ) : i === 1 ? (
              <Apple size={18} />
            ) : i === 2 ? (
              <Dumbbell size={18} />
            ) : (
              <Heart size={18} />
            )}{' '}
            {item}
          </button>
        ))}
        <div className="sidebar-note">
          <div className="note-icon">
            <Heart size={18} />
          </div>
          <strong>Earn your next level.</strong>
          <p>Daily quests. Real progress. No shortcuts.</p>
        </div>
        <div className="side-footer">
          <span className="status-dot" /> WINTER ARC ACTIVE
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <button
            className="mobile-menu"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
          >
            {menuOpen ? <X /> : <Menu />}
          </button>
          <div className="breadcrumb">
            Your space <span>/</span> <b>{tab}</b>
          </div>
          <button className="profile-pill" onClick={() => setTab('My profile')}>
            <span className="avatar">{age ? '🌱' : '☺️'}</span>
            <span>My profile</span>
            <ChevronRight size={15} />
          </button>
        </header>
        {menuOpen && (
          <div className="mobile-nav">
            {['Today', 'Meal ideas', 'Movement', 'My profile'].map(item => (
              <button
                key={item}
                onClick={() => {
                  setTab(item);
                  setMenuOpen(false);
                }}
              >
                {item}
              </button>
            ))}
          </div>
        )}

        {setup ? (
          <section className="setup-wrap">
            <div className="setup-art">
              <div className="sun-orb">☀️</div>
              <div className="art-leaf leaf-one">🌿</div>
              <div className="art-leaf leaf-two">🍃</div>
              <div className="art-copy">
                <span>WINTER ARC // PLAYER SETUP</span>
                <h1>
                  Enter your
                  <br />
                  Winter Arc.
                </h1>
                <p>
                  Build your streak. Collect XP. Get stronger one day at a time.
                </p>
              </div>
            </div>
            <form
              className="setup-card"
              onSubmit={e => {
                e.preventDefault();
                saveProfile(profile);
              }}
            >
              <div className="eyebrow">PLAYER CONFIGURATION</div>
              <h2>Create your player</h2>
              <p className="muted">
                Your details help us suggest age-appropriate habits. All fields
                are optional except age.
              </p>
              <label>
                How old are you?
                <div className="input-wrap">
                  <input
                    required
                    type="number"
                    min="5"
                    max="100"
                    value={profile.age}
                    onChange={e =>
                      setProfile({ ...profile, age: e.target.value })
                    }
                    placeholder="Your age"
                  />
                  <span>years</span>
                </div>
              </label>
              <div className="two-fields">
                <label>
                  Height{' '}
                  <div className="input-wrap">
                    <input
                      type="number"
                      min="50"
                      max="250"
                      value={profile.height}
                      onChange={e =>
                        setProfile({ ...profile, height: e.target.value })
                      }
                      placeholder="Optional"
                    />
                    <span>cm</span>
                  </div>
                </label>
                <label>
                  Weight{' '}
                  <div className="input-wrap">
                    <input
                      type="number"
                      min="10"
                      max="400"
                      value={profile.weight}
                      onChange={e =>
                        setProfile({ ...profile, weight: e.target.value })
                      }
                      placeholder="Optional"
                    />
                    <span>kg</span>
                  </div>
                </label>
              </div>
              <label>
                Choose your goal
                <select
                  value={profile.goal || 'fat-loss'}
                  onChange={e =>
                    setProfile({ ...profile, goal: e.target.value })
                  }
                >
                  <option value="fat-loss">Fat loss / build fitness</option>
                  <option value="weight-gain">Weight gain / build strength</option>
                </select>
              </label>
              <label>
                Usual activity level
                <select
                  value={profile.activity}
                  onChange={e =>
                    setProfile({ ...profile, activity: e.target.value })
                  }
                >
                  <option value="light">Mostly sitting / just starting</option>
                  <option value="moderate">Some walking or sports</option>
                  <option value="active">Active most days</option>
                </select>
              </label>
              <label>
                Food preference
                <select
                  value={profile.preference}
                  onChange={e =>
                    setProfile({ ...profile, preference: e.target.value })
                  }
                >
                  <option value="vegetarian">Vegetarian</option>
                  <option value="egg">Vegetarian + eggs</option>
                  <option value="nonveg">Includes meat / fish</option>
                </select>
              </label>
              <button className="primary-btn full-btn" type="submit">
                Create my plan <ChevronRight size={18} />
              </button>
              <p className="privacy-note">
                <Heart size={13} /> Your details stay in this browser on this
                device.
              </p>
            </form>
          </section>
        ) : (
          <div className="content">
            {tab === 'Today' && (
              <>
                <section className="welcome-row">
                  <div>
                    <div className="eyebrow">
                      {today.toUpperCase()} <span className="tiny-dot">•</span>{' '}
                      A FRESH START
                    </div>
                    <h1>Welcome to your Winter Arc.</h1>
                    <p className="muted">
                      You don't need a perfect day. Just one kind choice at a
                      time.
                    </p>
                  </div>
                  <div className="welcome-illustration">
                    🌼<span>✦</span>
                  </div>
                </section>
                {isTeen && (
                  <div className="gentle-banner">
                    <Heart size={19} />
                    <div>
                      <strong>Growing bodies need enough fuel.</strong>
                      <p>
                        We've kept your plan focused on energy, strength and
                        balanced meals — no calorie limits or weight-loss
                        targets.
                      </p>
                    </div>
                  </div>
                )}
                <section className="hero-card">
                  <div className="hero-text">
                    <span className="hero-kicker">
                      <Sparkles size={14} /> MAIN QUEST // DAILY RUN
                    </span>
                    <h2>The Winter Arc begins.</h2>
                    <p>Complete quests. Collect XP. Keep your streak alive.</p>
                    <button
                      className="hero-btn"
                      onClick={() => setTab('Movement')}
                    >
                      Open training quests <ChevronRight size={16} />
                    </button>
                  </div>
                  <div className="hero-graphic">
                    <div className="hero-circle">
                      <span>❄️</span>
                    </div>
                    <div className="float-chip chip-one">✦ One step</div>
                    <div className="float-chip chip-two">♥ You got this</div>
                  </div>
                </section>
                <section className="arc-stats">
                  <div className="rank-mark">❄</div>
                  <div className="rank-copy"><span>YOUR CURRENT RANK</span><strong>{rank}</strong><small>LEVEL {level} · {xp} XP</small></div>
                  <div className="xp-track"><div><span>LEVEL PROGRESS</span><b>{xp % 100}/100 XP</b></div><div className="xp-bar"><i style={{width: (xp % 100) + '%'}} /></div></div>
                </section>
                <div className="section-heading">
                  <div>
                    <h2>Daily quests</h2>
                    <p>Complete a quest to earn 25 XP.</p>
                  </div>
                  <button className="text-btn" onClick={resetDay}>
                    <RotateCcw size={14} /> Reset quests
                  </button>
                </div>
                <section className="habit-grid">
                  {[
                    {
                      id: 'move',
                      name: 'Movement quest',
                      desc: 'Choose movement you enjoy',
                      icon: <Activity />,
                      color: 'mint',
                    },
                    {
                      id: 'meals',
                      name: 'Fuel quest',
                      desc: 'Fuel up with balanced meals',
                      icon: <Utensils />,
                      color: 'peach',
                    },
                    {
                      id: 'water',
                      name: 'Hydration quest',
                      desc: 'Sip throughout your day',
                      icon: <Droplets />,
                      color: 'blue',
                    },
                    {
                      id: 'rest',
                      name: 'Recovery quest',
                      desc: 'Sleep and recovery matter',
                      icon: <Waves />,
                      color: 'lavender',
                    },
                  ].map(h => (
                    <button
                      key={h.id}
                      className={
                        'habit-card ' +
                        (done.includes(h.id) ? 'habit-done' : '')
                      }
                      onClick={() => h.id === 'move' ? setTab('Movement') : toggleDone(h.id)}
                    >
                      <div className={'habit-icon ' + h.color}>{h.icon}</div>
                      <div className="habit-copy">
                        <strong>{h.name}</strong>
                        <span>{h.desc}</span>
                      </div>
                      <span
                        className={
                          'check-circle ' +
                          (done.includes(h.id) ? 'checked' : '')
                        }
                      >
                        {done.includes(h.id) ? (
                          <Check size={15} />
                        ) : (
                          <ChevronRight size={15} />
                        )}
                      </span>
                    </button>
                  ))}
                </section>
                <section className="bottom-grid">
                  <div className="panel water-panel">
                    <div className="panel-title">
                      <div className="mini-icon blue">
                        <Droplets size={18} />
                      </div>
                      <div>
                        <h3>Water breaks</h3>
                        <p>Keep a drink nearby</p>
                      </div>
                    </div>
                    <div className="water-count">
                      <strong>{water}</strong>
                      <span>glasses logged</span>
                    </div>
                    <div className="water-buttons">
                      <button onClick={() => setWater(Math.max(0, water - 1))}>
                        −
                      </button>
                      <button onClick={() => setWater(Math.min(20, water + 1))}>
                        + Add a glass
                      </button>
                    </div>
                    <p className="small-hint">
                      A gentle reminder, not a strict target.
                    </p>
                  </div>
                  <div className="panel progress-panel">
                    <div className="panel-title">
                      <div className="mini-icon mint">
                        <Target size={18} />
                      </div>
                      <div>
                        <h3>Quest board</h3>
                        <p>Daily mission progress</p>
                      </div>
                    </div>
                    <div className="progress-line">
                      <div style={{ width: progress + '%' }} />
                    </div>
                    <div className="progress-bottom">
                      <strong>{done.filter(x => ['move','meals','water','rest'].includes(x)).length} of 4 quests</strong>
                      <span>{progress}%</span>
                    </div>
                    <p className="small-hint">
                      {done.length === 4
                        ? 'QUEST CLEAR! You showed up today.'
                        : 'Every small step counts. Pick what feels doable.'}
                    </p>
                  </div>
                </section>
              </>
            )}
            {tab === 'Meal ideas' && (
              <>
                <div className="page-intro">
                  <div className="eyebrow">LOADOUT // FOOD</div>
                  <h1>Your fuel loadout</h1>
                  <p className="muted">
                    Simple, flexible ideas using familiar foods. Eat enough to
                    feel satisfied and energized.
                  </p>
                </div>
                <div className="gentle-banner">
                  <Apple size={19} />
                  <div>
                    <strong>No foods need to be “earned”.</strong>
                    <p>
                      These are ideas, not strict rules. Adjust portions to your
                      hunger, needs and family meals.
                    </p>
                  </div>
                </div>
                <div className="meal-list">
                  {[...mealPlan, ...(profile.goal === 'weight-gain' ? [{ time: 'EXTRA FUEL', title: 'Add-on snack', meal: 'Try a smoothie with milk/yogurt and banana, peanut butter toast, or nuts alongside your usual meals', icon: '🥜' }] : [])].map((m, i) => (
                    <article className="meal-card" key={m.time}>
                      <div className="meal-emoji">{m.icon}</div>
                      <div className="meal-info">
                        <span>{m.time}</span>
                        <h3>{m.title}</h3>
                        <p>{m.meal}</p>
                      </div>
                      <span className="meal-num">0{i + 1}</span>
                    </article>
                  ))}
                </div>
                <div className="tip-card">
                  <Sparkles size={20} />
                  <div>
                    <strong>Easy plate idea</strong>
                    <p>
                      Mix and match a grain, a protein-rich food, vegetables or
                      fruit, and a satisfying fat when available. Snacks are
                      okay whenever you're hungry.
                    </p>
                  </div>
                </div>
                <button
                  className="outline-btn"
                  onClick={() => setTab('My profile')}
                >
                  Change food preference <ChevronRight size={16} />
                </button>
              </>
            )}
            {tab === 'Movement' && (
              <>
                <div className="page-intro">
                  <div className="eyebrow">TRAINING ROOM // QUESTS</div>
                  <h1>Choose your training quest</h1>
                  <p className="muted">
                    Start gently, take breaks, and stop if you feel pain, dizzy
                    or unwell.
                  </p>
                </div>
                <div className="workout-feature">
                  <div>
                    <span className="hero-kicker">
                      <Dumbbell size={14} /> {profile.goal === 'weight-gain' ? 'STRENGTH & RECOVERY' : 'CARDIO & FULL-BODY MOVEMENT'}
                    </span>
                    <h2>{profile.goal === 'weight-gain' ? 'Build strength, one quest at a time.' : 'Your movement quests are ready.'}</h2>
                    <p>
                      {profile.goal === 'weight-gain' ? 'Build confidence with beginner strength work, enough food and recovery.' : 'Mix enjoyable cardio with strength basics. No extreme workouts or punishment.'}
                    </p>
                  </div>
                  <div className="feature-emoji">🏃‍♀️</div>
                </div>
                <section className="panel" style={{ marginBottom: 20 }}>
                  <div className="panel-title">
                    <div className="mini-icon blue"><Dumbbell size={18} /></div>
                    <div>
                      <h3>Exercise library</h3>
                      <p>Search popular exercises and log what you complete</p>
                    </div>
                  </div>
                  <label style={{ display: 'block', margin: '16px 0 12px' }}>
                    Search any exercise
                    <input
                      type="search"
                      value={exerciseSearch}
                      onChange={e => setExerciseSearch(e.target.value)}
                      placeholder="Try bicep curls, squats, planks..."
                      aria-label="Search exercises"
                      style={{ display: 'block', width: '100%', marginTop: 8, padding: '12px 14px', borderRadius: 12, border: '1px solid var(--border, #334155)', background: 'var(--surface, #101a2b)', color: 'inherit', font: 'inherit' }}
                    />
                  </label>
                  <p className="small-hint">{filteredExercises.length} exercises found · 10 points for each exercise logged today</p>
                  <div className="workout-list">
                    {filteredExercises.map(exercise => {
                      const complete = todaysExercises.includes(exercise.name);
                      return (
                        <article className="workout-card" key={exercise.name}>
                          <div className="workout-emoji">{complete ? '✅' : '🏋️'}</div>
                          <div className="workout-info">
                            <div className="workout-title"><h3>{exercise.name}</h3><span>{exercise.group}</span></div>
                            <p>{exercise.equipment}</p>
                          </div>
                          <button className={'workout-check ' + (complete ? 'is-done' : '')} onClick={() => toggleExercise(exercise.name)} aria-label={(complete ? 'Unlog ' : 'Log ') + exercise.name}>
                            {complete ? <Check size={18} /> : <ChevronRight size={18} />}
                          </button>
                        </article>
                      );
                    })}
                    {filteredExercises.length === 0 && <p className="small-hint">No matches. Try a muscle group like arms, legs, chest or core.</p>}
                  </div>
                  <div className="tip-card" style={{ marginTop: 18 }}>
                    <Target size={20} />
                    <div>
                      <strong>Today's movement score: {todaysExercises.length * 10} points</strong>
                      <p>{todaysExercises.length} exercises logged. Scores track activity, not calories burned or body weight. Choose manageable movements, use controlled form, and rest when needed.</p>
                    </div>
                  </div>
                </section>
                <section className="panel" style={{ marginBottom: 20 }}>
                  <div className="panel-title">
                    <div className="mini-icon mint"><Target size={18} /></div>
                    <div><h3>7-day scorecard</h3><p>Your exercise log for the last seven days</p></div>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, minmax(0, 1fr))', gap: 8, marginTop: 16 }}>
                    {weeklyScores.map(day => <div key={day.key} style={{ textAlign: 'center', padding: '10px 3px', borderRadius: 10, background: day.key === dateKey ? 'rgba(96, 165, 250, .16)' : 'rgba(148, 163, 184, .08)', border: '1px solid rgba(148, 163, 184, .18)' }}><strong style={{ display: 'block', fontSize: 12 }}>{day.label}</strong><span style={{ display: 'block', fontSize: 13, marginTop: 6 }}>{day.score}</span><small style={{ opacity: .75 }}>pts</small></div>)}
                  </div>
                  <p className="small-hint" style={{ marginTop: 12 }}>Scores save on this device. Logging an exercise gives 10 points; unlogging it removes those points.</p>
                </section>
                <div className="workout-list">
                  {workouts.map((w, i) => (
                    <article className="workout-card" key={w.name}>
                      <div className="workout-emoji">{w.icon}</div>
                      <div className="workout-info">
                        <div className="workout-title">
                          <h3>{w.name}</h3>
                          <span>{w.level}</span>
                        </div>
                        <p>{w.detail}</p>
                        <div className="workout-time">
                          <Clock size={14} />
                          {w.time}
                        </div>
                      </div>
                      <button
                        className={
                          'workout-check ' +
                          (done.includes('workout-' + i) ? 'is-done' : '')
                        }
                        onClick={() => toggleDone('workout-' + i)}
                        aria-label={'Mark ' + w.name + ' complete'}
                      >
                        {done.includes('workout-' + i) ? (
                          <Check size={18} />
                        ) : (
                          <ChevronRight size={18} />
                        )}
                      </button>
                    </article>
                  ))}
                </div>
                <div className="tip-card">
                  <Heart size={20} />
                  <div>
                    <strong>Recovery is a power-up</strong>
                    <p>
                      Sleep, recovery and enjoyable movement matter more than
                      pushing hard every day. If you have health concerns, check
                      with a trusted adult or healthcare professional before
                      starting a new routine.
                    </p>
                  </div>
                </div>
              </>
            )}
            {tab === 'My profile' && (
              <>
                <div className="page-intro">
                  <div className="eyebrow">YOUR DETAILS</div>
                  <h1>Your profile</h1>
                  <p className="muted">
                    Update your preferences whenever you like.
                  </p>
                </div>
                <form
                  className="profile-form"
                  onSubmit={e => {
                    e.preventDefault();
                    saveProfile(profile);
                  }}
                >
                  <label>
                    Age{' '}
                    <div className="input-wrap">
                      <input
                        required
                        type="number"
                        min="5"
                        max="100"
                        value={profile.age}
                        onChange={e =>
                          setProfile({ ...profile, age: e.target.value })
                        }
                      />
                      <span>years</span>
                    </div>
                  </label>
                  <div className="two-fields">
                    <label>
                      Height{' '}
                      <div className="input-wrap">
                        <input
                          type="number"
                          min="50"
                          max="250"
                          value={profile.height}
                          onChange={e =>
                            setProfile({ ...profile, height: e.target.value })
                          }
                          placeholder="Optional"
                        />
                        <span>cm</span>
                      </div>
                    </label>
                    <label>
                      Weight{' '}
                      <div className="input-wrap">
                        <input
                          type="number"
                          min="10"
                          max="400"
                          value={profile.weight}
                          onChange={e =>
                            setProfile({ ...profile, weight: e.target.value })
                          }
                          placeholder="Optional"
                        />
                        <span>kg</span>
                      </div>
                    </label>
                  </div>
                  <label>
                    Choose your goal
                    <select
                      value={profile.goal || 'fat-loss'}
                      onChange={e =>
                        setProfile({ ...profile, goal: e.target.value })
                      }
                    >
                      <option value="fat-loss">Fat loss / build fitness</option>
                      <option value="weight-gain">Weight gain / build strength</option>
                    </select>
                  </label>
                  <label>
                    Usual activity level
                    <select
                      value={profile.activity}
                      onChange={e =>
                        setProfile({ ...profile, activity: e.target.value })
                      }
                    >
                      <option value="light">
                        Mostly sitting / just starting
                      </option>
                      <option value="moderate">Some walking or sports</option>
                      <option value="active">Active most days</option>
                    </select>
                  </label>
                  <label>
                    Food preference
                    <select
                      value={profile.preference}
                      onChange={e =>
                        setProfile({ ...profile, preference: e.target.value })
                      }
                    >
                      <option value="vegetarian">Vegetarian</option>
                      <option value="egg">Vegetarian + eggs</option>
                      <option value="nonveg">Includes meat / fish</option>
                    </select>
                  </label>
                  <button className="primary-btn full-btn" type="submit">
                    Save changes <Check size={17} />
                  </button>
                </form>
                <div className="gentle-banner">
                  <Heart size={19} />
                  <div>
                    <strong>{profile.goal === 'weight-gain' ? 'Strength grows with fuel and recovery.' : 'Build fitness without extreme rules.'}</strong>
                    <p>
                      {isTeen ? 'If you are still growing, don’t try to change your weight through restriction or supplements. Focus on enjoyable movement, regular balanced meals and talk with a trusted adult or healthcare professional about weight concerns.' : 'This goal changes your suggested movement and meal ideas, not a strict diet or a guaranteed weight outcome.'} Bloomfit keeps your preferences on this device and does not set calorie limits.
                    </p>
                  </div>
                </div>
              </>
            )}
            <footer className="footer">
              <span>❄ bloomfit winter arc</span>
              <span>Build your arc. One quest at a time.</span>
            </footer>
          </div>
        )}
      </main>
    </div>
  );
}
export default App;
